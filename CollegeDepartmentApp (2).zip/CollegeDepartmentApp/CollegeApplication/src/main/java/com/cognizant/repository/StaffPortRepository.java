package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.StaffPortSkell;

@Repository
public interface StaffPortRepository extends JpaRepository<StaffPortSkell, String>
{
	@Query("select stp from StaffPortSkell stp where stp.staffId=(:staffId) and stp.staffPassword=(:staffPassword)")
	StaffPortSkell findByLoginData(String staffId, String staffPassword);
}
