package com.cognizant.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "StudentBioDetails")
@Component
public class StudentDetSkell 
{
	@Id
	private String studentUsn;
	private String studentName;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date studentDob;
	private Long studentPhNum;
	private String studentEmail;
	private String houseNum_streetNum;
	private String area;
	private String city;
	private String state;
	private String country;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date studentDoa;
	 
	public StudentDetSkell() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentDetSkell(String studentUsn, String studentName, Date studentDob, Long studentPhNum, String studentEmail,
			String houseNum_streetNum, String area, String city, String state, String country,Date studentDoa) {
		super();
		this.studentUsn = studentUsn;
		this.studentName = studentName;
		this.studentDob = studentDob;
		this.studentPhNum = studentPhNum;
		this.studentEmail = studentEmail;
		this.houseNum_streetNum = houseNum_streetNum;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
		this.studentDoa = studentDoa;
	}
	public String getStudentUsn() {
		return studentUsn;
	}
	public void setStudentUsn(String studentUsn) {
		this.studentUsn = studentUsn;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Date getStudentDob() {
		return studentDob;
	}
	public void setStudentDob(Date studentDob) {
		this.studentDob = studentDob;
	}
	public Long getStudentPhNum() {
		return studentPhNum;
	}
	public void setStudentPhNum(Long studentPhNum) {
		this.studentPhNum = studentPhNum;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public String getHouseNum_streetNum() {
		return houseNum_streetNum;
	}
	public void setHouseNum_streetNum(String houseNum_streetNum) {
		this.houseNum_streetNum = houseNum_streetNum;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Date getStudentDoa() {
		return studentDoa;
	}
	public void setStudentDoa(Date studentDoa) {
		this.studentDoa = studentDoa;
	}
	@Override
	public String toString() {
		return "StudentDetSkell [studentUsn=" + studentUsn + ", studentName=" + studentName + ", studentDob=" + studentDob
				+ ", studentPhNum=" + studentPhNum + ", studentEmail=" + studentEmail + ", houseNum_streetNum="
				+ houseNum_streetNum + ", area=" + area + ", city=" + city + ", state=" + state + ", country=" + country +",studentDoa=" + studentDoa
				+ "]";
	}
	
}
