package com.cognizant.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "StudentPortalDetails")
@Component
public class StudentPortSkell 
{
	@Id
	private String studentUsn;
	private String studentName;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date studentDoa;
	private Long studentPhNum;
	private String studentEmail;
	private String studentPassword;
	
	public StudentPortSkell() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentPortSkell(String studentUsn, String studentName, Date studentDoa, Long studentPhNum,
			String studentEmail, String studentPassword) {
		super();
		this.studentUsn = studentUsn;
		this.studentName = studentName;
		this.studentDoa = studentDoa;
		this.studentPhNum = studentPhNum;
		this.studentEmail = studentEmail;
		this.studentPassword = studentPassword;
	}
	public String getStudentUsn() {
		return studentUsn;
	}
	public void setStudentUsn(String studentUsn) {
		this.studentUsn = studentUsn;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Date getStudentDoa() {
		return studentDoa;
	}
	public void setStudentDoa(Date studentDoa) {
		this.studentDoa = studentDoa;
	}
	public Long getStudentPhNum() {
		return studentPhNum;
	}
	public void setStudentPhNum(Long studentPhNum) {
		this.studentPhNum = studentPhNum;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public String getStudentPassword() {
		return studentPassword;
	}
	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}
	@Override
	public String toString() {
		return "StudentPortSkell [studentUsn=" + studentUsn + ", studentName=" + studentName + ", studentDoa="
				+ studentDoa + ", studentPhNum=" + studentPhNum + ", studentEmail=" + studentEmail
				+ ", studentPassword=" + studentPassword + "]";
	}
}
