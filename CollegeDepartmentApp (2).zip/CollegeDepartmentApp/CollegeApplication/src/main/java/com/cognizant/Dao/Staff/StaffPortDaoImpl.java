package com.cognizant.Dao.Staff;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.StaffPortSkell;
import com.cognizant.model.StudentPortSkell;
import com.cognizant.repository.StaffDetRepository;
import com.cognizant.repository.StaffPortRepository;

@Service
public class StaffPortDaoImpl implements StaffPortDao 
{
	@Autowired
	StaffPortRepository staffPortRepository;
	
	@Override
	public void updateStaffPort(StaffPortSkell staffPortSkell) 
	{
		// TODO Auto-generated method stub
		staffPortRepository.save(staffPortSkell);
	}

	@Override
	public StaffPortSkell validateStaff(StaffPortSkell staffPortSkell) {
		// TODO Auto-generated method stub
		StaffPortSkell staffPortSkell1 = staffPortRepository.findByLoginData(staffPortSkell.getStaffId(),staffPortSkell.getStaffPassword());
		return staffPortSkell1;
	}

	@Override
	public void addStaffPort(StaffPortSkell staffPortSkell) {
		// TODO Auto-generated method stub
		staffPortRepository.save(staffPortSkell);
	}

	@Override
	public void deleteStaffPort(String staffId) {
		// TODO Auto-generated method stub
		staffPortRepository.deleteById(staffId);
	}

	@Override
	public List<StaffPortSkell> getAllStaff() {
		List<StaffPortSkell> staffPortSkellLsit = staffPortRepository.findAll();
		return staffPortSkellLsit;
	}

	@Override
	public StaffPortSkell getStaffById(String staffId) 
	{
		StaffPortSkell staffPortSkell = staffPortRepository.getById(staffId);
		return staffPortSkell;
	}
}
