package com.cognizant.Dao.Staff;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.StaffPortSkell;
import com.cognizant.model.StudentPortSkell;

@Service
public interface StaffPortDao 
{
	public List<StaffPortSkell> getAllStaff();
	public StaffPortSkell getStaffById(String staffId);
	public void addStaffPort(StaffPortSkell StaffPortSkell);
	public void updateStaffPort(StaffPortSkell staffPortSkell);
	public StaffPortSkell validateStaff(StaffPortSkell staffPortSkell);
	public void deleteStaffPort(String staffId);
}
