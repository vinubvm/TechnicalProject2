package com.cognizant.Dao.Student;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.StudentDetSkell;

@Service
public interface StudentDetDao 
{
	public void addStudent(StudentDetSkell studentDetSkell);
	public StudentDetSkell getStudentByUsn(String studentUsn);
	public void updateStudentDet(StudentDetSkell studentDetSkell);
	public List<StudentDetSkell> getAllStudent();
	public void deleteStudentDet(String studentUsn);
	//public StudentDetSkell validateStudentDet(StudentDetSkell studentDetSkell);
}
