package com.cognizant.Dao.Admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.AdminDetSkell;
import com.cognizant.repository.AdminDetRepository;

@Service
public class AdminDetDaoImpl implements AdminDetDao {

	@Autowired
	AdminDetRepository adminDetRepository; 
	
	@Override
	public AdminDetSkell validateAdmin(AdminDetSkell adminDetSkell) 
	{
		// TODO Auto-generated method stub
		AdminDetSkell adminDetSkell1 = adminDetRepository.findByLoginData(adminDetSkell.getAdminId(),adminDetSkell.getAdminPassword()); 
		return adminDetSkell1;
	}
}
